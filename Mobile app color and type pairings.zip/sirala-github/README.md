# Sırala — tasarım ve demo

QR ile sipariş ve canlı sıra takibi için müşteri ve kasa ekranlarının tasarımı.

## Dosyalar

```
index.html            Çalışan demo (tek dosya, internetsiz de açılır)
tasarim/
  Sirala Demo.dc.html       Demonun kaynak dosyası
  Sirala Pairings.dc.html   Renk ve yazı eşleşmeleri (turn 1 ve 2)
  Sirala Screens*.dc.html   Eşleşme sayfasının ekran parçaları
  support.js, _ds/          Tasarım dosyalarının çalışması için gerekli
```

## Demoyu açmak

- Bilgisayarda: `index.html` dosyasına çift tıkla.
- Telefonda: GitHub'da depo → **Settings → Pages → Branch: main / root → Save**. Birkaç dakika sonra `https://KULLANICI.github.io/DEPO/` adresinden açılır; bu adresle QR üretebilirsin.

## Demoda neler var

- Müşteri: kategorili menü (Kahveler, Soğuk kahveler, Çay ve sıcaklar, Soğuk içecekler, Atıştırmalıklar, Tatlılar), sepet, Kart/Nakit, sıra numarası, canlı "Şu an / Önünde", 3 sıra kala ses + titreşim, siparişi değiştir (numara aynı), iptal, Hazır.
- Kasa: Ödendi, 3 sıra geri at, İptal, Hazır, Tükendi.
- Otomatik mod sırayı her 3 saniyede ilerletir; kapatınca kasadan elle ilerletilir.

Veriler sahtedir ve tek telefonda çalışır; sayfa yenilenince sıfırlanır. Gerçek sürüm Firebase'li `sirala/` kodudur.

## Görsel dil

- Zemin: koyu lacivert (#161826), üstte hafif çivit ışıltı
- Ana renk: şampanya altını (#d4b37a), açık tonu #ecdcb8, koyu dolgu #2c2619
- İkinci renk: mor (#9184d9), uyarı ve durumlarda
- Yazı: başlık ve sıra numarası Instrument Serif, metin Inter, fiyatlar Sora

## Sıradaki işler

- Bu görsel dili gerçek sürümün `public/css/style.css` dosyasına taşımak
- Kasada "Elden sipariş" sekmesi
- Kasa için tablet yerleşimi
